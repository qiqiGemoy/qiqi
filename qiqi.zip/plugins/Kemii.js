let { sticker } = require('../lib/sticker.js')

let handler = async (m, { conn }) => {
  conn.sendMessage(m.chat, {
    react: {
      text: '🕒',
      key: m.key,
    }
  });
let stiker = await sticker(null, global.API(`${pickRandom(stikerhuuu)}`), global.packname, global.author)
    if (stiker) return conn.sendFile(m.chat, stiker, 'sticker.webp', '', m)
    throw stiker.toString()
    
}

handler.customPrefix = /^(Pp|p)/i
handler.command = new RegExp
// handler.private = true
module.exports = handler

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}
let stikerhuuu= [

'https://telegra.ph/file/c1d5ee0f4f208e6f577a4.png',
'https://telegra.ph/file/6e140f3da2305cdf457ad.jpg',
'https://telegra.ph/file/36e414649d45959d05f2f.jpg',
	'https://telegra.ph/file/c1af2580a947b8c91f884.png'	
]